﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace Organizer
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void usernameBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            StreamReader old = new StreamReader("testpages/logins.txt");
            string theold = old.ReadToEnd();
            old.Close();
            StreamWriter user = new StreamWriter("testpages/logins.txt");

            user.WriteLine(theold);
            user.Write(usernameBox.Text);
            user.Write(":");
            user.Write(passwordBox.Text);
            
            user.Close();

            this.Hide();
        }
    }
}
